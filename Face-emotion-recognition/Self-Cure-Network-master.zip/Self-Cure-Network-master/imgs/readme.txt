This is our proposed method pipeline of SCN.
